create trigger narocila__ai
  after INSERT
  on narocila
  for each row
  INSERT INTO trgovina.narocila_arh SELECT 'insert', NULL, NOW(), d.* 
    FROM trgovina.narocila AS d WHERE d.idnarocila = NEW.idnarocila;

