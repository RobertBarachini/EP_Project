create trigger uporabniki__au
  after UPDATE
  on uporabniki
  for each row
  INSERT INTO trgovina.uporabniki_arh SELECT 'update', NULL, NOW(), d.*
    FROM trgovina.uporabniki AS d WHERE d.iduporabnika = NEW.iduporabnika;

