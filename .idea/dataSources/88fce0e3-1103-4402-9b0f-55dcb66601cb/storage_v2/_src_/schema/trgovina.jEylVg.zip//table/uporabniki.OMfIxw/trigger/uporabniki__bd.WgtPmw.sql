create trigger uporabniki__bd
  before DELETE
  on uporabniki
  for each row
  INSERT INTO trgovina.uporabniki_arh SELECT 'delete', NULL, NOW(), d.* 
    FROM trgovina.uporabniki AS d WHERE d.iduporabnika = OLD.iduporabnika;

