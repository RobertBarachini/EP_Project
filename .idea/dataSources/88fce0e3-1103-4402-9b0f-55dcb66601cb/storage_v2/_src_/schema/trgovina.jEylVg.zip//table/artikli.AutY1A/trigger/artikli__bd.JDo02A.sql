create trigger artikli__bd
  before DELETE
  on artikli
  for each row
  INSERT INTO trgovina.artikli_arh SELECT 'delete', NULL, NOW(), d.* 
    FROM trgovina.artikli AS d WHERE d.idartikla = OLD.idartikla;

