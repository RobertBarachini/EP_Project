create trigger artikli__au
  after UPDATE
  on artikli
  for each row
  INSERT INTO trgovina.artikli_arh SELECT 'update', NULL, NOW(), d.*
     FROM trgovina.artikli AS d WHERE d.idartikla = NEW.idartikla;

