create trigger narocila__bd
  before DELETE
  on narocila
  for each row
  INSERT INTO trgovina.narocila_arh SELECT 'delete', NULL, NOW(), d.* 
    FROM trgovina.narocila AS d WHERE d.idnarocila = OLD.idnarocila;

