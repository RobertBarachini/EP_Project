create trigger narocila__au
  after UPDATE
  on narocila
  for each row
  INSERT INTO trgovina.narocila_arh SELECT 'update', NULL, NOW(), d.*
     FROM trgovina.narocila AS d WHERE d.idnarocila = NEW.idnarocila;

