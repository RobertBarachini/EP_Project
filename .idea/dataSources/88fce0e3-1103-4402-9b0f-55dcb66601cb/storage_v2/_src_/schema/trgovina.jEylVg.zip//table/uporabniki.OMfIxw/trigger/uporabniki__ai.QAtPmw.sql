create trigger uporabniki__ai
  after INSERT
  on uporabniki
  for each row
  INSERT INTO trgovina.uporabniki_arh SELECT 'insert', NULL, NOW(), d.* 
    FROM trgovina.uporabniki AS d WHERE d.iduporabnika = NEW.iduporabnika;

