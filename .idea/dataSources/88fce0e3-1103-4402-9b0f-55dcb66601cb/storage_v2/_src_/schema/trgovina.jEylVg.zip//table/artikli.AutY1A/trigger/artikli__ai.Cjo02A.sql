create trigger artikli__ai
  after INSERT
  on artikli
  for each row
  INSERT INTO trgovina.artikli_arh SELECT 'insert', NULL, NOW(), d.* 
    FROM trgovina.artikli AS d WHERE d.idartikla = NEW.idartikla;

